from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from app.prompts import PROMPT_VERSION
from storage.json_store import JsonStore


def now_iso() -> str:
    return datetime.now().isoformat(timespec='seconds')


def default_memory() -> Dict[str, Any]:
    return {
        'profile': {
            'goals': [],
            'bad_patterns': [],
            'commitments': [],
            'preferred_style': 'strict',
        },
        'messages': [],
        'sessions': {},
        'stats': {
            'total_messages': 0,
            'last_model': None,
            'prompt_version': PROMPT_VERSION,
        },
        'last_updated': now_iso(),
    }


class MemoryStore:
    def __init__(self, path: Path):
        self.store = JsonStore(path)

    def load(self) -> Dict[str, Any]:
        memory = self.store.read(default_memory())
        base = default_memory()
        for key, value in base.items():
            memory.setdefault(key, value)
        memory.setdefault('profile', base['profile'])
        for key, value in base['profile'].items():
            memory['profile'].setdefault(key, value)
        memory.setdefault('sessions', {})
        if memory.get('messages') and 'default' not in memory['sessions']:
            memory['sessions']['default'] = {'messages': memory['messages']}
        for session_id, session_data in list(memory['sessions'].items()):
            if not isinstance(session_data, dict):
                memory['sessions'][session_id] = {'messages': []}
                continue
            session_data.setdefault('messages', [])
        return memory

    def load_session(self, session_id: str) -> Dict[str, Any]:
        memory = self.load()
        session = memory['sessions'].setdefault(session_id, {'messages': []})
        return {
            'profile': memory['profile'],
            'messages': session.get('messages', []),
            'stats': memory['stats'],
            'last_updated': memory['last_updated'],
        }

    def save(self, memory: Dict[str, Any]) -> None:
        memory['last_updated'] = now_iso()
        self.store.write(memory)

    def append_turn(self, user_input: str, reply: str, model: str | None, latency: float | None, session_id: str = 'default') -> None:
        memory = self.load()
        session = memory['sessions'].setdefault(session_id, {'messages': []})
        session['messages'].append({'role': 'user', 'content': user_input, 'created_at': now_iso()})
        session['messages'].append({
            'role': 'assistant',
            'content': reply,
            'model': model,
            'latency_seconds': latency,
            'created_at': now_iso(),
        })
        memory['messages'] = memory['sessions'].get('default', {}).get('messages', [])
        memory['stats']['total_messages'] = sum(len(item.get('messages', [])) for item in memory['sessions'].values())
        memory['stats']['last_model'] = model
        memory['stats']['prompt_version'] = PROMPT_VERSION
        self.save(memory)

    def add_profile_item(self, category: str, value: str) -> bool:
        allowed = {'goals', 'bad_patterns', 'commitments'}
        if category not in allowed:
            raise ValueError(f'Invalid category: {category}')
        memory = self.load()
        items: List[str] = memory['profile'].setdefault(category, [])
        value = value.strip()
        if not value or value in items:
            return False
        items.append(value)
        self.save(memory)
        return True
